//
// Created by RDS on 4/12/2017.
//

#include <jni.h>
#include <string>

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <unistd.h>

//#define _WIN32
//#define __ANDROID__

extern "C"
void
Triangle_drawTriangle(JNIEnv *env, jobject instance,
                      jobject mTriangle, jfloatArray scratch) {


    const char* Triangle_draw_sig = "([F)V";
    jclass Triangle_clazz = env->GetObjectClass(mTriangle);
    env->NewGlobalRef(mTriangle);
    jmethodID Triangle_draw_method = env->GetMethodID(Triangle_clazz,
                                                                       "draw",
                                                      Triangle_draw_sig);
    env->CallVoidMethod(mTriangle, Triangle_draw_method, scratch);

}

#ifdef __cplusplus
extern "C" {
#endif

static int loadShader(int type, const GLchar* shaderCode){

    // create a vertex shader type (GLES20.GL_VERTEX_SHADER)
    // or a fragment shader type (GLES20.GL_FRAGMENT_SHADER)
    int shader = glCreateShader(type);

    // add the source code to the shader and compile it
    glShaderSource(shader, 1, &shaderCode, 0);
    glCompileShader(shader);

    return shader;
}

static void initGL(int& mProgram ) {
    const GLchar* vertexShaderCode =
            // This matrix member variable provides a hook to manipulate
            // the coordinates of the objects that use this vertex shader
            "uniform mat4 uMVPMatrix; \
            attribute vec4 vPosition; \
            void main() { \
            // the matrix must be included as a modifier of gl_Position \
            // Note that the uMVPMatrix factor *must be first* in order \
            // for the matrix multiplication product to be correct. \
              gl_Position = uMVPMatrix * vPosition; \
            }";

    const GLchar* fragmentShaderCode =
            "precision mediump float; \
            uniform vec4 vColor;  \
            void main() {  \
              gl_FragColor = vColor; \
            }";

    const GLchar* const* vertexShaderCodePtr = &vertexShaderCode;
    const GLchar* const* fragmentShaderCodePtr = &fragmentShaderCode;

    int vertexShader = loadShader(GL_VERTEX_SHADER, vertexShaderCode);
    int fragmentShader = loadShader(GL_FRAGMENT_SHADER, fragmentShaderCode);

    mProgram = glCreateProgram();             // create empty OpenGL Program
    glAttachShader(mProgram, vertexShader);   // add the vertex shader to program
    glAttachShader(mProgram, fragmentShader); // add the fragment shader to program
    glLinkProgram(mProgram);
}

static void drawNative_(JNIEnv *env, jobject triangle, jfloatArray mvpMatrix_,
                        jobject vertexBuffer, jint mProgram_,
                        jint mPositionHandle, jint mColorHandle,
                        jint mMVPMatrixHandle, jint COORDS_PER_VERTEX,
                        jint vertexCount, jint vertexStride,
                        jfloatArray color_) {
    env->NewGlobalRef(vertexBuffer);
    env->NewGlobalRef(triangle);
    env->NewGlobalRef(mvpMatrix_);
    env->NewGlobalRef(color_);
    jfloat *mvpMatrixF = env->GetFloatArrayElements(mvpMatrix_, NULL);
    jsize mvpMatrixSize = env->GetArrayLength(mvpMatrix_);
    float *mvpMatrix = new float[mvpMatrixSize];
    for (int i = 0; i < mvpMatrixSize; i++) {
        mvpMatrix[i] = mvpMatrixF[i];
    }

    jfloat *colorF = env->GetFloatArrayElements(color_, NULL);
    jsize colorSize = env->GetArrayLength(color_);
    float *color = new float[colorSize];
    for (int i = 0; i < colorSize; i++) {
        color[i] = colorF[i];
    }
    // Add program to OpenGL environment
    int mProgram = 0;
    //initGL(mProgram);
    mProgram = mProgram_;
    glUseProgram(mProgram);

    // get handle to vertex shader's vPosition member
    mPositionHandle = glGetAttribLocation(mProgram, "vPosition");

    // Enable a handle to the triangle vertices
    glEnableVertexAttribArray(mPositionHandle);

    // Prepare the triangle coordinate data
    glVertexAttribPointer(
            mPositionHandle, COORDS_PER_VERTEX,
            GL_FLOAT, false,
            vertexStride, vertexBuffer);

    // get handle to fragment shader's vColor member
    mColorHandle = glGetUniformLocation(mProgram, "vColor");

    // Set color for drawing the triangle
    //glUniform4fv(mColorHandle, 1, color, 0);
    glUniform4fv(mColorHandle, 1, color);

    // get handle to shape's transformation matrix
    mMVPMatrixHandle = glGetUniformLocation(mProgram, "uMVPMatrix");
    jclass MyGLRendererClazz = env->FindClass("com/example/opengl/AndroidGLRenderer");
    jmethodID MyGLRendererClazz_checkGlError_Mthd = env->GetStaticMethodID(MyGLRendererClazz,
                                                                           "checkGlError", "(Ljava/lang/String;)V");
    jstring strarg1 = env->NewStringUTF("glGetUniformLocation");
    env->CallStaticVoidMethod(MyGLRendererClazz, MyGLRendererClazz_checkGlError_Mthd,
                              strarg1);
    //AndroidGLRenderer.checkGlError("glGetUniformLocation");

    // Apply the projection and view transformation
    //glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix, 0);
    glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix);
    jstring strarg2 = env->NewStringUTF("glUniformMatrix4fv");
    env->CallStaticVoidMethod(MyGLRendererClazz, MyGLRendererClazz_checkGlError_Mthd,
                              strarg2);
    //AndroidGLRenderer.checkGlError("glUniformMatrix4fv");

    // Draw the triangle
    glDrawArrays(GL_TRIANGLES, 0, vertexCount);

    // Disable vertex array
   glDisableVertexAttribArray(mPositionHandle);

    jclass MyTriangleClazz = env->GetObjectClass(triangle);
    jmethodID MyTriangleClazz_drawBasic_Mthd = env->GetMethodID(MyTriangleClazz, "drawBasic", "([F)V");
    env->CallVoidMethod(triangle, MyTriangleClazz_drawBasic_Mthd, mvpMatrix_);

    //env->ReleaseFloatArrayElements(mvpMatrix_, mvpMatrixF, 0);
   // delete[] mvpMatrix;
    //env->ReleaseFloatArrayElements(color_, colorF, 0);
   // delete[] color;
}
#ifdef __cplusplus
}
#endif

extern "C"
JNIEXPORT void JNICALL
Java_com_example_opengl_Triangle_drawNative(JNIEnv *env, jobject triangle, jfloatArray mvpMatrix_,
                                            jobject vertexBuffer, jint mProgram,
                                            jint mPositionHandle, jint mColorHandle,
                                            jint mMVPMatrixHandle, jint COORDS_PER_VERTEX,
                                            jint vertexCount, jint vertexStride,
                                            jfloatArray color_) {
    env->NewGlobalRef(vertexBuffer);
    env->NewGlobalRef(triangle);
    env->NewGlobalRef(mvpMatrix_);
    env->NewGlobalRef(color_);
    drawNative_(env, triangle, mvpMatrix_,
            vertexBuffer, mProgram,
            mPositionHandle, mColorHandle,
            mMVPMatrixHandle, COORDS_PER_VERTEX,
            vertexCount, vertexStride,
            color_);

}


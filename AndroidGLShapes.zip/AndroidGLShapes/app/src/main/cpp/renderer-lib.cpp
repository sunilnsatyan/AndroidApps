//
// Created by RDS on 4/13/2017.
//
#include <jni.h>
#include <string>

extern "C"
void Traingle_drawTraingle(JNIEnv *env, jobject instance,
                      jobject mTriangle, jfloatArray scratch);

extern "C"
JNIEXPORT void JNICALL
Java_com_example_opengl_AndroidGLRenderer_drawTraingle(JNIEnv *env, jobject instance,
        jobject mTriangle, jfloatArray scratch) {
    env->NewGlobalRef(mTriangle);
    env->NewGlobalRef(scratch);
    //Traingle_drawTraingle(env,  instance, mTriangle, scratch);
    const char* Traingle_draw_sig = "([F)V";
    jclass Triangle_clazz = env->GetObjectClass(mTriangle);
    //env->NewGlobalRef(mTriangle);
    jmethodID Traingle_draw_method = env->GetMethodID(Triangle_clazz,
                                                      "draw",
                                                      Traingle_draw_sig);
    env->CallVoidMethod(mTriangle, Traingle_draw_method, scratch);
}


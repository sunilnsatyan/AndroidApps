#include <jni.h>
#include <string>

#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/log.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_androidvideoplayer_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject mainActivityObj) {
    std::string hello = "Now Playing from C++ ...";
    jstring retStr = env->NewStringUTF(hello.c_str());
    // Invoke Call back on this to set the string from C++
    jclass MainActivity_class = env->GetObjectClass(mainActivityObj);
    const char* MainActivity_setTextViewString_sig = "(Ljava/lang/String;)V";
    jmethodID MainActivity_setTextViewString_method = env->GetMethodID(MainActivity_class,
                                                                "setTextViewString",
                                                                MainActivity_setTextViewString_sig);
    env->CallVoidMethod(mainActivityObj, MainActivity_setTextViewString_method, retStr);
    return retStr;
}

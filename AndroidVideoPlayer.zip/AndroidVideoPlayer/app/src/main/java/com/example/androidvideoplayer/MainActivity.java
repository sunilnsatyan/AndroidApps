package com.example.androidvideoplayer;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.SoundPool;
import android.net.Uri;
import android.opengl.GLSurfaceView;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.SoundEffectConstants;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.android.opengl.MyGLSurfaceView;

import static android.view.View.SOUND_EFFECTS_ENABLED;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    VideoView videoView ;
    private int position = 0;
    GLSurfaceView glSurfaceView= null;
    SurfaceView surfaceView=null;
    MyGLSurfaceView myGLSurfaceView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        stringFromJNI();
        //myGLSurfaceView = new MyGLSurfaceView(this);
        //addContentView(myGLSurfaceView, myGLSurfaceView.getLayoutParams());
        // Example of a call TO a native method
    }

    public void setTextViewString(String jniString) {
        // Example of a call FROM a native method
        TextView tv = (TextView) findViewById(R.id.textView);
        tv.setText(jniString);
    }

    public void toastonoff(View v) {
        Toast.makeText(MainActivity.this, "Power On/Off",
                Toast.LENGTH_SHORT).show();
        videoView = (VideoView) findViewById(R.id.videoView);
        try {
            //set the uri of the video to be played
            videoView.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.waterfalls));

            final RelativeLayout rel = (RelativeLayout)findViewById(R.id.relLayout);
            surfaceView = (SurfaceView)findViewById(R.id.surfaceView);

            final Context context = rel.getContext();
            final Context surfaceViewContext = surfaceView.getContext();
            final ViewGroup.LayoutParams params = rel.getLayoutParams();
            videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                   // rel.clearAnimation();
                    //vview.clearAnimation();
                    //rel.removeView(vview);
                    //rel.removeAllViews();
                   // glSurfaceView = new GLSurfaceView(surfaceViewContext);
                   // glSurfaceView.setEGLContextClientVersion(2);
                    //glSurfaceView.setRenderer(mRenderer);
                    myGLSurfaceView = new MyGLSurfaceView(surfaceViewContext);
                    /*
                   TextView textView = (TextView) findViewById(R.id.textView);
                   Bitmap bitmap = textView.getDrawingCache();
                   int w = bitmap.getWidth();
                    int h = bitmap.getHeight();
                    for (int i = 0; i < w; i++) {
                        for (int j = 0; j < h; j++) {
                            bitmap.setPixel(i,j,0);
                        }
                    }
                    //bitmap.recycle();
                    */
                }
            });
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }
        videoView.requestFocus();
        //we also set an setOnPreparedListener in order to know when the video file is ready for playback
        videoView.setOnPreparedListener(new OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                // close the progress bar and play the video
                //if we have a position on savedInstanceState, the video playback should start from here
                videoView.seekTo(position);
                if (position == 0) {
                    videoView.start();
                } else {
                    //if we come from a resumed activity, video playback will be paused
                    videoView.pause();
                }
            }
        });
    }

    public void toastplay(View v) {
        Toast.makeText(MainActivity.this, "Play",
                Toast.LENGTH_SHORT).show();
        if (position == 0) {
            videoView.start();
        } else {
            //videoView.seekTo(position);
            //videoView.resume();
            videoView.start();
        }
    }

    public void toastpause(View v) {
        Toast.makeText(MainActivity.this, "Pause",
                Toast.LENGTH_SHORT).show();
        position = videoView.getCurrentPosition();
        videoView.pause();
    }

    public void toastrew(View v) {
        Toast.makeText(MainActivity.this, "Rew",
                Toast.LENGTH_SHORT).show();
        videoView.start();
    }

    public void toastff(View v) {
        Toast.makeText(MainActivity.this, "FF",
                Toast.LENGTH_SHORT).show();
        position = videoView.getDuration();
        videoView.seekTo(position);
    }

    public void toastvolume(View v) {
        Toast.makeText(MainActivity.this, "Volume",
                Toast.LENGTH_SHORT).show();
        videoView.setSoundEffectsEnabled(true);
        videoView.playSoundEffect(SoundEffectConstants.CLICK);
    }
    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}
